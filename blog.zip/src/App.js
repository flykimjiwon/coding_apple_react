/* eslint-disable */
import logo from './logo.svg';
import './App.css';
import {useState} from 'react'

function App() {


  let [글제목, 글제목변경] = useState(['서울','대구','대전','광주'])
  let [따봉,따봉변경] = useState([0,0,0,0])

  let [modal,modal변경] = useState(false) 
  let posts = "군자 훠궈 맛집" 
  let [누른제목,누른제목변경] = useState(0);


  let [글발행,글발행변경] = useState('');


  function 제목바꾸기(){
    console('제목바꾸기')
    var newArray = [...글제목]
    newArray[0] = '뉴욕'
    newArray = newArray.sort()    
    글제목변경(newArray)
  }

  function 따봉바꾸기(index){
    var newArray = [...따봉]
    newArray[index] = newArray[index] + 1
    따봉변경(newArray)
  }

  


  return (
    <div className="App">
      <div className="black-nav">
        <div >개발 BLOG</div>
      </div>
     
      

      {
        글제목.map(function(글, i){
          return(
            <div className='list' key={i}>
              <h3 onClick={ ()=>{ 누른제목변경(i)}} > {글} <span onClick={() => {따봉바꾸기(i)}}>🥰좋아요!</span> {따봉[i]}</h3>
              <p>1월 10일 발행</p>
              <hr/>
            </div>
          )
        })
      }

    {글발행}
    <div className='publish'>
      <input onChange={ (e)=>{글발행변경(e.target.value)} }></input>
      <button onClick = { ()=>{ 
        var arrayCopy = [...글제목]
        arrayCopy.unshift(글발행)
        글제목변경(arrayCopy)
       } }>저장</button>
    </div>


      <button onClick = {()=>{modal변경(!modal)}}>모달창</button>

      {
        modal === true
        ? <Modal 글제목 = {글제목} 누른제목 = {누른제목}></Modal> 
        : null
      }
         
    </div>
  );
}

function Modal(props){ 
  return(
    <div className="modal">
        <h2>제목 {props.글제목[props.누른제목]}</h2> 
        <p>날짜</p>
        <p>상세내용</p>
      </div>
  )
}

<input></input>

export default App;
